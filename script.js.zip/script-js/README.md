# script.js

A Pen created on CodePen.

Original URL: [https://codepen.io/Maimuna-Samreen/pen/gbaybmb](https://codepen.io/Maimuna-Samreen/pen/gbaybmb).

